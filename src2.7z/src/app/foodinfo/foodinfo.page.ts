import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foodinfo',
  templateUrl: './foodinfo.page.html',
  styleUrls: ['./foodinfo.page.scss'],
})
export class FoodinfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
