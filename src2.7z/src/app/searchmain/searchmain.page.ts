import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchmain',
  templateUrl: './searchmain.page.html',
  styleUrls: ['./searchmain.page.scss'],
})
export class SearchmainPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
