import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foodposter',
  templateUrl: './foodposter.page.html',
  styleUrls: ['./foodposter.page.scss'],
})
export class FoodposterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
