import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chefpanel',
  templateUrl: './chefpanel.page.html',
  styleUrls: ['./chefpanel.page.scss'],
})
export class ChefpanelPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
